create function calculatesectorinfo()
  returns trigger
language plpgsql
as $$
BEGIN
NEW.area = cast(area(path(NEW.shape)) as double precision);
RETURN NEW;
END;
$$;

