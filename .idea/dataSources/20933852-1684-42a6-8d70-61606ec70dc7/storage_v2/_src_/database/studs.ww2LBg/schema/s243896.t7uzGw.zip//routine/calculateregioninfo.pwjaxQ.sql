create function calculateregioninfo()
  returns trigger
language plpgsql
as $$
BEGIN
NEW.area = cast(area(path(NEW.shape)) as double precision);
NEW.center = point(NEW.shape);
RETURN NEW;
END;
$$;

