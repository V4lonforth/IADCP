create function getdistance(pos1 point, pos2 point)
  returns double precision
language plpgsql
as $$
declare
radius constant double precision := 6371;
begin
return radius * acos(sin(radians(pos1[0])) * sin(radians(pos2[0])) + cos(radians(pos1[0])) * cos(radians(pos2[0])) * cos(radians(pos1[1]) - radians(pos2[1])));
end;
$$;

